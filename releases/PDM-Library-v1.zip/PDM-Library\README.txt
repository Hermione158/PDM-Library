﻿PDM Library - Lending & Reservations System
============================================

HOW TO START
------------
1. Copy this whole PDM-Library folder to a place you can write to,
   such as the Desktop or Documents folder. Do NOT run it from inside
   a ZIP file - unzip it first.
2. Double-click  PDM-Library.exe
3. Sign in with one of the accounts below.

No installation is needed. Python is not required on this computer.


SIGN-IN ACCOUNTS
----------------
Librarian / Circulation desk   username: teope    password: pdmstaff
                               username: soy      password: pdmstaff
                               username: karen    password: pdmstaff
                               username: janine   password: pdmstaff

Administrator                  username: admin    password: pdmadmin

Students create their own account from the Student tab on the sign-in
screen, using their student number, a name, program, year level and
section.


WHAT IS INSIDE THE FOLDER
-------------------------
PDM-Library.exe     the program - this is what you run
library.db          ALL the data lives here
README.txt          this file
_internal\          support files the program needs - do not edit


BACKING UP - IMPORTANT
----------------------
Everything the system knows lives in  one file:  library.db

To back up: copy library.db to a USB drive or another folder.
To restore: put your copy back in this folder, overwriting the current
one, then run PDM-Library.exe.

Do a backup at the end of each day. That single file is the whole
system - if it is lost, all loans, reservations and SDO cases are lost.


FORGOT A PASSWORD?
------------------
A student or staff member should see the administrator at the library
desk. The administrator resets it for them on the Users screen
(double-click the account, then Reset password). The person is then
asked to set their own password using "Change password" at the bottom
of the sidebar.


MULTIPLE COMPUTERS
------------------
This system is built for ONE computer. If you copy the folder to a
second PC, the two copies will each keep their own separate data and
will drift apart. Do not use it on two computers at the same time
without asking for advice first.


IF WINDOWS WARNS YOU
--------------------
The first time you open the program Windows may show a blue message
about an unrecognized publisher. Choose  More info  and then
Run anyway. This is normal for programs that are not digitally signed.
